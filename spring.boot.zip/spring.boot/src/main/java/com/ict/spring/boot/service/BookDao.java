package com.ict.spring.boot.service;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.ict.spring.boot.domain.Book;

@Service
public class BookDao {
	Connection con;
	PreparedStatement pstTitle;
	PreparedStatement pstSubject;

	public BookDao() {
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost/books", "root", "password-1");
			
			pstTitle = con.prepareStatement("select * from book where upper(title)=?");
			pstSubject = con.prepareStatement("select * from book where upper(title) like ?");
		} catch (SQLException e) {

			e.printStackTrace();
		}
	}

	public Book getBookOnTitle(String title) throws SQLException {
		pstTitle.setString(1, title.toUpperCase());
		ResultSet rs = pstTitle.executeQuery();
		if (rs.next()) {
			return makeBook(rs);
		}
		return null;
	}

	public List<Book> getBooksOnSubject(String subject) throws SQLException {
		List<Book> list = new ArrayList<>();
		pstSubject.setString(1, subject.toUpperCase() + "%");
		ResultSet rs = pstSubject.executeQuery();
		while (rs.next()) {
			Book book = makeBook(rs);
			list.add(book);
		}
		return list;
	}

	private Book makeBook(ResultSet rs) throws SQLException {

		int id = rs.getInt("id");
		String title = rs.getString("title");
		String author = rs.getString("author");
		int price = rs.getInt("price");
		int quantity = rs.getInt("quantity");
		Book book = new Book(id, title, author, price, quantity);
		return book;
	}

	@Override
	public void finalize() {
		try {
			con.close();
		} catch (SQLException e) {

			e.printStackTrace();
		}
	}
}
