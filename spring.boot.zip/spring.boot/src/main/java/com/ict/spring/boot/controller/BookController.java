package com.ict.spring.boot.controller;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ict.spring.boot.domain.Book;
import com.ict.spring.boot.service.BookDao;

@Controller

public class BookController {
	@Autowired
	BookDao dao;
	
	@GetMapping(path="/")
	public String showIndex(){
		return "index";
	}
	 @GetMapping(path="/getBookData")
	   public String getBookData(@RequestParam("option") String option, @RequestParam("searchtext") String text,Model model) {
		
	     try{
	      if(option.equals("title")){
	    	  Book bk=dao.getBookOnTitle(text);
	    	  if(bk==null){
	    		  model.addAttribute("errorMessage","Book with title "+text+" does not exist");
	    		  return "error";
	    	  }
	    	  model.addAttribute("book",bk);
	    	  return "book";
	      }
	      else{
	    	  List<Book> list=dao.getBooksOnSubject(text);
	    	  if(list.size()==0){
	    		  model.addAttribute("errorMessage","No books available on subject "+text);
	    		  return "error";
	    	  }
	    	  model.addAttribute("bookList",list);
	    	  return "subject";
	      }
	     }catch(SQLException ex){
	    	 model.addAttribute("errormessage", "Unknown error");
	    	 return "error";
	     }
	   }

}
