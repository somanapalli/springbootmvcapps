package com.spring.practice;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HelloController {
	
	@RequestMapping("/")
	public String home()
	{
		return "index";
	}
	@RequestMapping("/hello")
	public String process(HttpServletRequest request, Model m)
	{
		
		String name= request.getParameter("name");
		String pass= request.getParameter("pass");
		if(pass.equals("admin"))
		{
			String msg = "Welcome " +name;
			m.addAttribute("message", msg);
			return "viewpage";
			
		}
		else
		{
			String msg = "Sorry the " +name + " entered is wrong please check";
			m.addAttribute("message",msg);
			return "errorpage";
		}
	}

}
