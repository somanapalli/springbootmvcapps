package com.spring.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
public class HelloController1 {
	
	/*@RequestMapping("/hello")
	public String display()
	{
		return "viewpage";
	}
	@RequestMapping("/helloagain")
	public String show()
	{
		return "final";
	}*/
	@RequestMapping("/")
	public String home()
	{
		return "index";
	}
	@RequestMapping("/hello1")  
    public String redirect()  
    {  
        return "viewpage1";  
    }   
	
	
/*@RequestMapping("/helloagain")  
public String display()  
{  
    return "final";  
} */


}
